function[PIr,opo,qqq,SSL] = outage(toy)
uu=toy;
disp("\n#####################OUTAGE PROGRAM######################")
% Load power system data, including Ybus, initialVoltage, generation, and load data.
fprintf('\n IEEE bus number:: %d',uu);
if uu==3||uu==6||uu==9||uu==14||uu==30||uu==57||uu==118
num = uu;  
a=0;b=0;
busd = busdatas(num);
busdd = busdatas(num);
z=length(busdd);
BMva = 100;                 % Base MVA..
bus = busd(:,1);            % Bus Number..
type = busd(:,2);           % Type of Bus 1-Slack, 2-PV, 3-PQ..
V = busd(:,3);              % Specified Voltage..
del = zeros(length(V),1);   % Voltage Angle..
Pg = busd(:,5)/BMva;        % PGi..
Qg = busd(:,6)/BMva;        % QGi..
Pl = busd(:,7)/BMva;        % PLi..
Ql = busd(:,8)/BMva;        % QLi..
Qmin = busd(:,9)/BMva;      % Minimum Reactive Power Limit..
Qmax = busd(:,10)/BMva;     % Maximum Reactive Power Limit..
nbus = max(bus);            % To get no. of buses..
P = Pg - Pl;                % Pi = PGi - PLi..
Q = Qg - Ql;                % Qi = QGi - QLi..
Psp = P;                    % P Specified       
Qsp = Q;                    % Q Specified
linedata = linedatas(num);  % Calling Linedatas...
linedataa = linedatas(num);
fb = linedata(:,1);                     % From bus number...
kk=length(fb);
tb = linedata(:,2);  
pv = find(type == 2 | type == 1);       % Index of PV Buses..
pq = find(type == 3);                   % Index of PQ Buses..
npv = length(pv);                       % Number of PV buses..
npq = length(pq);                       % Number of PQ buses..
po=zeros(kk,1);qq=zeros(kk,1);
opo=zeros(kk,1);qqq=zeros(kk,1);
for m=1:kk
opo(m)=fb(m);qqq(m)=tb(m);
end
for m=1:kk
po(m)=fb(m);qq(m)=tb(m);
end
nl = length(fb);
YY = ybusppg(num,linedatas(num));
[R,BMva] = nrlfppg(num,YY,linedatas(num),busdatas(num));
E=R;
Before=R;
k= input('\n FOR LINE OUTAGE PRESS 1 AND FOR GENERATOR PRESS 2(FOR N-1 CONTINGENCY)::');
if k==1
 disp('\n You have to enter the bus number in which the line is present!!');
 a=input('\Enter the from bus: ');
 b= input('\n Enter the to bus:');
 bb = busdatas(num); 
for i=1:length(fb) 
    for j=1:length(tb)
        if (fb(i)==a && tb(j)==b)
fprintf('\n*************outage of line between %d - %d ***************',a,b)
condition = (linedataa(:,1) == a) & (linedataa(:,2) == b);
linedataa(condition, :) = [];
l=linedataa;
Y = ybusppg(num,l);
        end
    end
end
[R,BMva] = nrlfppg(num,Y,l,bb);
M=R;
elseif k==2
    busdd ;
    disp('\n BUS DATAS ARE :');
    busdd
    a=input('\n Enter Generator no. For outage ::');
    con=(busdd(:,1)==a);
    busdd(con,:) = [0];
    b=busdd;
    [R,BMva]= nrlfppg(num,YY,linedatas(num),b);
    M=R;
    for i=1:z
    if isnan(M(i))
        M(i)=0;
    end
end
else
    disp('\n WRONG NUMBER!!!')
end
disp('\n MVA BEFORE CONT.')
disp('|From|To |  MVA Rating |');
disp('|Bus |Bus|     MVA     |');
for m = 1:nl
    p = fb(m); zz = tb(m); w = E(m);
     fprintf('%4g', p); fprintf('%4g', zz); fprintf('   %8.2f',w);
     fprintf('\n');
end
else
    disp('\n WRONG NUMBER!!!')
end
x=input('\n Manually Delete the number of entry From Before contingency:');
E(x)=[];fb(x)=[];tb(x)=[];
disp('|From|To |  MVA Rating |');
disp('|Bus |Bus|     MVA     |');
for m = 1:nl-1
    p = fb(m); ww = tb(m); w = E(m);
     fprintf('%4g', p); fprintf('%4g', ww); fprintf('   %8.2f',w);
     fprintf('\n');
end
disp('\n Maximum limit 2*(Before Contingency data)!!');
for r=1:nl-1
    P(r)=(1.5*E(r));
end
disp('\n MVA BEFORE CONT.')
disp('|From|To |  MVA Rating |');
disp('|Bus |Bus|     MVA     |');
for m = 1:nl-1
    p = fb(m); aa = tb(m); w = P(m);
     fprintf('%4g', p); fprintf('%4g', aa); fprintf('   %8.2f',w);
     fprintf('\n');
end
disp('\n MVA AFTER CONT.')
disp('|From|To |  MVA Rating |');
disp('|Bus |Bus|     MVA     |');
for m = 1:nl-1
    p = fb(m); q = tb(m); w = M(m);
     fprintf('%4g', p); fprintf('%4g', q); fprintf('   %8.2f',w);
     fprintf('\n');
end
%fprintf('#####################TEST 1 CASE PASS#########################');
for r=1:nl
    PP(r)=(Before(r));
end
disp('|From|To |  MVA Rating |');
disp('|Bus |Bus|     MVA     |');
for m = 1:nl
    p = po(m); q = qq(m); w = PP(m);
     fprintf('%4g', p); fprintf('%4g', q); fprintf('   %8.2f',w);
     fprintf('\n');
end
xx=input('\n Manually Delete the number of entry From Before contingency:');
PP(xx)=[];po(xx)=[];qq(xx)=[];

%% for finding the Max change 
for r=1:nl-1
    change(r)=(100*(M(r)-(PP(r)))/(PP(r)));
end
pchange=abs(max(change));
for rr=1:nl-1
    value(rr)=((PP(rr)*1.2)-M(rr));
end
kk=0;
for op=1:nl-1
    if value(op)<0
        kk=kk+1;
    else
        kk=0;
    end
end
sun=max(M);
        
for m = 1:nl-1
     C(m)=M(m)/P(m);
end
for m = 1:nl-1
     T(m)=(1/2)*((C(m))^2);
end
PI=0;
for m=1:nl-1
    PI=PI+T(m);
end
fprintf('\n*************PI value for line %d - %d ***************',a,b);
PI
PIr=PI;
fprintf('#############################################################' );
SS = (((1+kk)*pchange)/(PI*sun));
fprintf('\n*************SSL value for line %d - %d ***************',a,b);
SS
SSL=SS;

end

