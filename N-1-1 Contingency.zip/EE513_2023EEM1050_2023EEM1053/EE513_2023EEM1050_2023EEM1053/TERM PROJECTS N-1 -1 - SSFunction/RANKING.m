clc;clear all;
disp("\n##################RANKING PROGRAM########################")
toy=input('\n Enter the bus Number(3,6,9,14,30,57,118)::');
if toy==3||toy==6||toy==9||toy==14||toy==30||toy==57||toy==118
pp = linedatas(toy); 
fb = pp(:,1);
nl=length(fb);
h=zeros(nl,1);
hh=zeros(nl,1);
flag=input('\n Press 1 for Outage program and 2 for exit::')
if flag==1
    for m = 1:nl
    fprintf('\n######OUTAGE FOR %d !',m);
    [PIr,po,qq,SSL] = outage(toy);
    h(m,1)= PIr;
    hh(m,1)=SSL;
    fprintf('\n');
    end
po=po;qq=qq;
disp('|From|To |  PI RANKING  |   HALF SSL FUNCTION');
disp('|Bus |Bus|     RANK     |                    ');
    for m = 1:nl
    p = po(m); q = qq(m); w = h(m);rr=hh(m);
     fprintf('%4g', p); fprintf('%4g', q); fprintf('   %8.2f',w), fprintf('        %14.8f',rr);
     fprintf('\n');
     end
toto=zeros(nl,4);
toto(:,1)=po;
toto(:,2)=qq;
toto(:,3)=h;
toto(:,4)=hh;
also=zeros(nl,4);
also=sortrows(toto,3,'descend') ;
 for m = 1:nl
     w = also(m,3);
    if isnan(w)
        also(m,3)=0.000001;
    end
 end
 data =zeros(nl,3);
 disp('\n ')
disp("\nRANKING ACCORDING TO PI!!!")
disp('RANK|From|To |  PI RANKING  |   FULL SSL FUNCTION');
disp('    |Bus |Bus|     RANK     |                    ');
   for m = 1:nl
    p = also(m,1); q = also(m,2); w = also(m,3);rr=((toy+1)-p)*also(m,4);
     fprintf('%4g',m);fprintf('%4g', p); fprintf('%4g', q); fprintf('   %8.2f',w);fprintf('        %14.8f',rr);
     fprintf('\n');
     data(m,1)=p;
     data(m,2)=q;
     data(m,3)=rr;
   end
%%%%%%%%%%%%%%###############################%%%%%%%%%%%%%%%%
% Find all possible additions of the third column values
[m,n] = size(data);

% Initialize an array to store all possible additions
valuesMatrix = zeros(m*(m-1)/2, 5);
rowIndex = 1;
for i = 1:m
    for j = i+1:m
        if i <= m && j <= m 
            sumCol3 = data(i, 3) + data(j, 3);
            fprintf('\n Additions of Line %d-%d and Line %d-%d:',data(i,1),data(i,2),data(j,1),data(j,2));
            disp(sumCol3);
            valuesMatrix(rowIndex, :) = [data(i,1), data(i,2), data(j,1), data(j,2), sumCol3];
            rowIndex = rowIndex + 1;
        end
    end
end
sortedValuesMatrix = sortrows(valuesMatrix, 5,'descend');
disp('################################################################');
fprintf('**************N-1-1 CONTINGENCY ANALYSIS*********************');
[numRows, numCols] = size(sortedValuesMatrix);
SVM = sortedValuesMatrix;
for i = 1:numRows
        fprintf('\n Additions of Line %d-%d and Line %d-%d----->%1.5f',SVM(i,1),SVM(i,2),SVM(i,3),SVM(i,4),SVM(i,5));
        disp('            ');
        disp('          ');
end
fprintf('\n******************THANK YOU ******************************* \n');
else
    disp("\n Press Any key to exit!!")
end
else 
    disp('\n Entered Wrong Number Press Any key to exit!!')
end